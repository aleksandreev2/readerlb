# ReaderLB MangaLib exact fixture

Это уменьшенный fixture, собранный из реального локального MangaLib-архива.

Целевой путь на Android:

`/storage/emulated/0/Android/data/ru.libappc/files/manga/990001--readerlb-manga-fixture/`

Структура:

```text
manga/
└── 990001--readerlb-manga-fixture/
    ├── info.json
    ├── chapters.json
    └── v1-n1-990101.zip
```

Внутри главы страницы записаны ФИЗИЧЕСКИ в таком порядке:

```text
p10-3368541
p2-3368533
p18-3368549
p1-3368532
```

Все страницы — реальные AVIF-файлы БЕЗ расширения.

Правильный логический порядок после natural sort:

```text
p1-3368532
p2-3368533
p10-3368541
p18-3368549
```

`p18-3368549` — горизонтальная страница 1003×800.
Остальные выбранные страницы используются для проверки обычного page pipeline.

Fixture должен использоваться для:
- обнаружения `files/manga`;
- чтения `info.json`;
- чтения `chapters.json`;
- обнаружения ZIP главы без `data.txt`;
- определения AVIF по magic bytes, а не расширению;
- natural sorting страниц;
- portrait/landscape;
- экспорта CBZ/PDF;
- будущего round-trip теста.

Не меняйте fixture так, чтобы ZIP entries уже лежали в правильном порядке — неправильный физический порядок сделан намеренно.
